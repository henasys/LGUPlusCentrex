﻿namespace VS2008_OpenAPI
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axLGUBaseOpenApi1 = new AxLGUBASEOPENAPILib.AxLGUBaseOpenApi();
            this.label1 = new System.Windows.Forms.Label();
            this.strLoginID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.strLoginPW = new System.Windows.Forms.TextBox();
            this.logbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.strLoginIP = new System.Windows.Forms.TextBox();
            this.Connect = new System.Windows.Forms.Button();
            this.disConn = new System.Windows.Forms.Button();
            this.strTelNum = new System.Windows.Forms.TextBox();
            this.Dial = new System.Windows.Forms.Button();
            this.Answer = new System.Windows.Forms.Button();
            this.Hangup = new System.Windows.Forms.Button();
            this.Hold = new System.Windows.Forms.Button();
            this.Unhold = new System.Windows.Forms.Button();
            this.Pickup = new System.Windows.Forms.Button();
            this.StartRecord = new System.Windows.Forms.Button();
            this.StopRecord = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axLGUBaseOpenApi1)).BeginInit();
            this.SuspendLayout();
            // 
            // axLGUBaseOpenApi1
            // 
            this.axLGUBaseOpenApi1.Enabled = true;
            this.axLGUBaseOpenApi1.Location = new System.Drawing.Point(622, 3);
            this.axLGUBaseOpenApi1.Name = "axLGUBaseOpenApi1";
            this.axLGUBaseOpenApi1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axLGUBaseOpenApi1.OcxState")));
            this.axLGUBaseOpenApi1.Size = new System.Drawing.Size(100, 50);
            this.axLGUBaseOpenApi1.TabIndex = 0;
            this.axLGUBaseOpenApi1.SendNetworkErrorEvent += new System.EventHandler(this.axLGUBaseOpenApi1_SendNetworkErrorEvent);
            this.axLGUBaseOpenApi1.SendEtcEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendEtcEventEventHandler(this.axLGUBaseOpenApi1_SendEtcEvent);
            this.axLGUBaseOpenApi1.SendLoginResultEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendLoginResultEventEventHandler(this.axLGUBaseOpenApi1_SendLoginResultEvent);
            this.axLGUBaseOpenApi1.SendChannelListEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendChannelListEventEventHandler(this.axLGUBaseOpenApi1_SendChannelListEvent);
            this.axLGUBaseOpenApi1.SendRingEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendRingEventEventHandler(this.axLGUBaseOpenApi1_SendRingEvent);
            this.axLGUBaseOpenApi1.SendCmdErrorEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendCmdErrorEventEventHandler(this.axLGUBaseOpenApi1_SendCmdErrorEvent);
            this.axLGUBaseOpenApi1.SendChannelOutEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendChannelOutEventEventHandler(this.axLGUBaseOpenApi1_SendChannelOutEvent);
            this.axLGUBaseOpenApi1.SendCommandResultEvent += new AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendCommandResultEventEventHandler(this.axLGUBaseOpenApi1_SendCommandResultEvent);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID : ";
            // 
            // strLoginID
            // 
            this.strLoginID.Location = new System.Drawing.Point(47, 10);
            this.strLoginID.Name = "strLoginID";
            this.strLoginID.Size = new System.Drawing.Size(100, 21);
            this.strLoginID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "PW : ";
            // 
            // strLoginPW
            // 
            this.strLoginPW.Location = new System.Drawing.Point(47, 38);
            this.strLoginPW.Name = "strLoginPW";
            this.strLoginPW.Size = new System.Drawing.Size(100, 21);
            this.strLoginPW.TabIndex = 2;
            // 
            // logbox
            // 
            this.logbox.Location = new System.Drawing.Point(13, 92);
            this.logbox.Multiline = true;
            this.logbox.Name = "logbox";
            this.logbox.Size = new System.Drawing.Size(709, 258);
            this.logbox.TabIndex = 0;
            this.logbox.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "IP : ";
            // 
            // strLoginIP
            // 
            this.strLoginIP.Location = new System.Drawing.Point(47, 63);
            this.strLoginIP.Name = "strLoginIP";
            this.strLoginIP.Size = new System.Drawing.Size(100, 21);
            this.strLoginIP.TabIndex = 3;
            // 
            // Connect
            // 
            this.Connect.Location = new System.Drawing.Point(154, 22);
            this.Connect.Name = "Connect";
            this.Connect.Size = new System.Drawing.Size(75, 23);
            this.Connect.TabIndex = 4;
            this.Connect.Text = "접속";
            this.Connect.UseVisualStyleBackColor = true;
            this.Connect.Click += new System.EventHandler(this.Connect_Click);
            // 
            // disConn
            // 
            this.disConn.Location = new System.Drawing.Point(154, 50);
            this.disConn.Name = "disConn";
            this.disConn.Size = new System.Drawing.Size(75, 23);
            this.disConn.TabIndex = 0;
            this.disConn.TabStop = false;
            this.disConn.Text = "종료";
            this.disConn.UseVisualStyleBackColor = true;
            this.disConn.Click += new System.EventHandler(this.disConn_Click);
            // 
            // strTelNum
            // 
            this.strTelNum.Location = new System.Drawing.Point(273, 10);
            this.strTelNum.Name = "strTelNum";
            this.strTelNum.Size = new System.Drawing.Size(100, 21);
            this.strTelNum.TabIndex = 0;
            this.strTelNum.TabStop = false;
            // 
            // Dial
            // 
            this.Dial.Location = new System.Drawing.Point(379, 8);
            this.Dial.Name = "Dial";
            this.Dial.Size = new System.Drawing.Size(75, 23);
            this.Dial.TabIndex = 0;
            this.Dial.TabStop = false;
            this.Dial.Text = "전화걸기";
            this.Dial.UseVisualStyleBackColor = true;
            this.Dial.Click += new System.EventHandler(this.Dial_Click);
            // 
            // Answer
            // 
            this.Answer.Location = new System.Drawing.Point(273, 38);
            this.Answer.Name = "Answer";
            this.Answer.Size = new System.Drawing.Size(75, 23);
            this.Answer.TabIndex = 0;
            this.Answer.TabStop = false;
            this.Answer.Text = "전화받기";
            this.Answer.UseVisualStyleBackColor = true;
            this.Answer.Click += new System.EventHandler(this.Answer_Click);
            // 
            // Hangup
            // 
            this.Hangup.Location = new System.Drawing.Point(273, 63);
            this.Hangup.Name = "Hangup";
            this.Hangup.Size = new System.Drawing.Size(75, 23);
            this.Hangup.TabIndex = 0;
            this.Hangup.TabStop = false;
            this.Hangup.Text = "전화끊기";
            this.Hangup.UseVisualStyleBackColor = true;
            this.Hangup.Click += new System.EventHandler(this.Hangup_Click);
            // 
            // Hold
            // 
            this.Hold.Location = new System.Drawing.Point(379, 38);
            this.Hold.Name = "Hold";
            this.Hold.Size = new System.Drawing.Size(75, 23);
            this.Hold.TabIndex = 0;
            this.Hold.TabStop = false;
            this.Hold.Text = "보류";
            this.Hold.UseVisualStyleBackColor = true;
            this.Hold.Click += new System.EventHandler(this.Hold_Click);
            // 
            // Unhold
            // 
            this.Unhold.Location = new System.Drawing.Point(379, 63);
            this.Unhold.Name = "Unhold";
            this.Unhold.Size = new System.Drawing.Size(75, 23);
            this.Unhold.TabIndex = 0;
            this.Unhold.TabStop = false;
            this.Unhold.Text = "보류해제";
            this.Unhold.UseVisualStyleBackColor = true;
            this.Unhold.Click += new System.EventHandler(this.Unhold_Click);
            // 
            // Pickup
            // 
            this.Pickup.Location = new System.Drawing.Point(460, 8);
            this.Pickup.Name = "Pickup";
            this.Pickup.Size = new System.Drawing.Size(75, 23);
            this.Pickup.TabIndex = 0;
            this.Pickup.TabStop = false;
            this.Pickup.Text = "당겨받기";
            this.Pickup.UseVisualStyleBackColor = true;
            this.Pickup.Click += new System.EventHandler(this.Pickup_Click);
            // 
            // StartRecord
            // 
            this.StartRecord.Location = new System.Drawing.Point(486, 38);
            this.StartRecord.Name = "StartRecord";
            this.StartRecord.Size = new System.Drawing.Size(75, 23);
            this.StartRecord.TabIndex = 0;
            this.StartRecord.TabStop = false;
            this.StartRecord.Text = "녹취시작";
            this.StartRecord.UseVisualStyleBackColor = true;
            this.StartRecord.Click += new System.EventHandler(this.StartRecord_Click);
            // 
            // StopRecord
            // 
            this.StopRecord.Location = new System.Drawing.Point(486, 63);
            this.StopRecord.Name = "StopRecord";
            this.StopRecord.Size = new System.Drawing.Size(75, 23);
            this.StopRecord.TabIndex = 0;
            this.StopRecord.TabStop = false;
            this.StopRecord.Text = "녹취종료";
            this.StopRecord.UseVisualStyleBackColor = true;
            this.StopRecord.Click += new System.EventHandler(this.StopRecord_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 362);
            this.Controls.Add(this.StopRecord);
            this.Controls.Add(this.StartRecord);
            this.Controls.Add(this.Pickup);
            this.Controls.Add(this.Unhold);
            this.Controls.Add(this.Hold);
            this.Controls.Add(this.Hangup);
            this.Controls.Add(this.Answer);
            this.Controls.Add(this.Dial);
            this.Controls.Add(this.strTelNum);
            this.Controls.Add(this.disConn);
            this.Controls.Add(this.Connect);
            this.Controls.Add(this.strLoginIP);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.logbox);
            this.Controls.Add(this.strLoginPW);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.strLoginID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.axLGUBaseOpenApi1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axLGUBaseOpenApi1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxLGUBASEOPENAPILib.AxLGUBaseOpenApi axLGUBaseOpenApi1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox strLoginID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox strLoginPW;
        private System.Windows.Forms.TextBox logbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox strLoginIP;
        private System.Windows.Forms.Button Connect;
        private System.Windows.Forms.Button disConn;
        private System.Windows.Forms.TextBox strTelNum;
        private System.Windows.Forms.Button Dial;
        private System.Windows.Forms.Button Answer;
        private System.Windows.Forms.Button Hangup;
        private System.Windows.Forms.Button Hold;
        private System.Windows.Forms.Button Unhold;
        private System.Windows.Forms.Button Pickup;
        private System.Windows.Forms.Button StartRecord;
        private System.Windows.Forms.Button StopRecord;
    }
}

