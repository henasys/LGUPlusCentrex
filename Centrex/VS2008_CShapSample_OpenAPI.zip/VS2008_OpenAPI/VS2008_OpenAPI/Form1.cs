﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VS2008_OpenAPI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void axLGUBaseOpenApi1_SendLoginResultEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendLoginResultEventEvent e)
        {
            logbox.AppendText(e.bstrLoginResult.ToString() + "\n");
        }

        private void axLGUBaseOpenApi1_SendNetworkErrorEvent(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.DisconnectServer();
            logbox.AppendText("Network Error disconnected : " + e.ToString() + "\n");
        }

        private void axLGUBaseOpenApi1_SendCmdErrorEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendCmdErrorEventEvent e)
        {
            logbox.AppendText(e.bstrMsgValue.ToString() + "\n");
        }

        private void axLGUBaseOpenApi1_SendCommandResultEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendCommandResultEventEvent e)
        {
            logbox.AppendText(e.bstrCommandResult.ToString() + "\n");
        }

        private void axLGUBaseOpenApi1_SendEtcEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendEtcEventEvent e)
        {
            logbox.AppendText(e.bstrEventValue.ToString() + "\n");
        }

        private void axLGUBaseOpenApi1_SendRingEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendRingEventEvent e)
        {
            logbox.AppendText(e.bstrRingEvent.ToString() + "\n");
        }

        private void axLGUBaseOpenApi1_SendChannelListEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendChannelListEventEvent e)
        {
            logbox.AppendText(e.bstrChannelList.ToString() + "\n");

        }

        private void axLGUBaseOpenApi1_SendChannelOutEvent(object sender, AxLGUBASEOPENAPILib._DLGUBaseOpenApiEvents_SendChannelOutEventEvent e)
        {
            logbox.AppendText(e.bstrChannelOut.ToString() + "\n");
        }

        private void Connect_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.LoginServer(strLoginID.Text.ToString(), strLoginPW.Text.ToString(), strLoginIP.Text.ToString());
        }

        private void disConn_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.DisconnectServer();
        }

        private void Dial_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.Click2Call(strTelNum.Text.ToString(), "", "");
        }

        private void Answer_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.Answer();
        }

        private void Hangup_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.HangUp();
        }

        private void Hold_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.Hold();
        }

        private void Unhold_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.Unhold();
        }

        private void Pickup_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.Pickup(strTelNum.Text.ToString());
        }

        private void StartRecord_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.StartRecord();
        }

        private void StopRecord_Click(object sender, EventArgs e)
        {
            axLGUBaseOpenApi1.StopRecord();
        }
    }
}
